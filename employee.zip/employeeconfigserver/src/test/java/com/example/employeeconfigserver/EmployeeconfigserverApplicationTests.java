package com.example.employeeconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeconfigserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
