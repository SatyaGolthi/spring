package com.example.employeesearchservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
 
	@Autowired
	EmployeeRepository employeeRepository;
	
	public String addEmployee(Employee emp) {
		employeeRepository.save(emp);
		return "SUCCESS";
	}
}
