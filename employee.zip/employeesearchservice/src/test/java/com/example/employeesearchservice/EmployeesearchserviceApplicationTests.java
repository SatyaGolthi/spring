package com.example.employeesearchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesearchserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
