package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class EmployeeController {

	@Autowired
	RestTemplate template;
	
	@PostMapping("/addclient")
	public String addEmployee()
	{
		String url="http://empsearchservice:1234/add";
		Employee e = new Employee(3,"XYZ", 123.00);
		ResponseEntity<String> response =template.postForEntity(url,e, String.class); 
		return response.getBody();
	}
	
}
